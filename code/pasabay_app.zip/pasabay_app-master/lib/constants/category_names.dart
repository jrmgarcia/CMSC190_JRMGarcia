const String Cleaning = "Cleaning";
const String Delivery = "Delivery";
const String Officework = "Officework";
const String PetSitting = "Pet Sitting";
const String Schoolwork = "Schoolwork";